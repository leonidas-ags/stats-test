/* eslint-disable no-console */
// eslint-disable-next-line
const execa = require('execa');
const fs = require('fs');

(async () => {
  try {
    await execa('git', ['checkout', '--orphan', 'gh-pages']);
    console.log('Building...');
    await execa('npm', ['run', 'build']);
    const folderName = fs.existsSync('dist') ? 'dist' : 'build';
    await execa('git', ['--work-tree', folderName, 'add', '--all']);
    await execa('git', ['--work-tree', folderName, 'commit', '-m', 'gh-pages']);
    console.log('Pushing...');
    await execa('git', ['push', 'origin', 'HEAD:gh-pages', '--force']);
    console.log('Cleaning up ...');
    fs.rmdirSync('dist', { recursive: true });
    await execa('git', ['checkout', '-f', 'main']);
    await execa('git', ['branch', '-D', 'gh-pages']);
    console.log('Successfully published to gh-pages');
  } catch (e) {
    console.log(e.message);
  }
})();
