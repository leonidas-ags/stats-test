<template>
  <div id="404">
    <b-jumbotron
      header="404 Seite nicht gefunden!"
      lead="Versuche es doch mal auf einer anderen Seite...">
    </b-jumbotron>
  </div>
</template>
